import React from "react";
import Button from "@mui/material/Button";
import BookmarkBorderIcon from "@mui/icons-material/BookmarkBorder";
import BookmarkIcon from "@mui/icons-material/Bookmark";
import Checkbox from "@mui/material/Checkbox";

const Card = ({ data }) => {
  const styles = {
    fontFamily: "'Proxima Nova', Arial, sans-serif",
    fontSize: "14px",
    // letterSpacing: "1.2941335439682007px",
    textAlign: "center",
    borderRadius: 47,
    backgroundColor: "#5CA4A9",
  };
  return (
    <div className="card mt-1">
      <div className="card-body row">
        {/* Image */}
        <div className="col-2">
          <img
            src={data.image}
            alt={data.companyName}
            style={{ width: "80px", height: "80px", borderRadius: "18.91px" }}
          />
        </div>
        {/* Data */}
        <div className="col-7">
          <div>
            <h5 className="card-title">{data.jobName}</h5>
            <p className="card-text">
              <strong>Location:</strong> {data.location}
            </p>
            <p className="card-text">
              <strong>Company:</strong> {data.companyName}
            </p>
          </div>
        </div>
        <div className="col-3">
          <div className="skills">
            <p>Skills match</p>
          </div>
        </div>
      </div>
      <div className="card-footer row" style={{ color: "white" }}>
        <div className=" col-6">
          <p>Posted 1 day ago . {data.applicants} applicants</p>
        </div>
        <div className="col-6 d-flex justify-content-end">
          <Button variant="contained" style={styles}>
            Apply Now
          </Button>

          <Checkbox
            icon={<BookmarkBorderIcon />}
            checkedIcon={<BookmarkIcon />}
          />
        </div>
      </div>
    </div>
  );
};

export default Card;
