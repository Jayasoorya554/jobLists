import * as React from "react";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";

export default function Dropdown(props) {
  const [expanded, setExpanded] = React.useState(false);

  const handleExpansion = () => {
    setExpanded((prevExpanded) => !prevExpanded);
  };

  return (
    <>
      <Accordion
        className="row"
        style={{ backgroundColor: "#171c28", color: "white" }}
      >
        <AccordionSummary
          className="col-12"
          expandIcon={<ExpandMoreIcon style={{ color: "white" }} />}
          aria-controls="panel2-content"
          id="panel2-header"
        >
          <Typography>{props.data.name}</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <FormGroup>
            {props.data.value.map((value, index) => (
              <FormControlLabel
                key={index}
                control={<Checkbox />}
                label={value}
              />
            ))}
          </FormGroup>
        </AccordionDetails>
      </Accordion>
      <hr />
    </>
  );
}
