import React, { useState, useEffect } from "react";
import Card from "./Card"; // Assuming you have a Card component
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Dropdown from "./DD/Dropdown";

const YourComponent = () => {
  const location = {
    name: "Location",
    value: ["Chennai", "Coimbatore"],
  };
  const company = {
    name: "Company",
    value: ["Amazon", "CVS Health", "Apple"],
  };
  const datePosted = {
    name: "Date Posted",
    value: [
      "Last 24 hours",
      "Last 48 hours",
      "Last 7 days",
      "Last 14 days",
      "Last month",
    ],
  };
  const salary = {
    name: "Salary Range",
    value: ["3 Lakh+", "6 Lakh+", "10 Lakh+", "15 Lakh+", "25 Lakh+"],
  };
  const skills = {
    name: "Skills",
    value: [
      "Javacript",
      "Machine Learning",
      "JQuery",
      "Artificial Intelligence",
    ],
  };
  const education = {
    name: "Education",
    value: ["Bachelors", "Masters", "PhD", "Diplomo"],
  };
  const exp = {
    name: "Experience",
    value: ["0-2 years", "3-5 years", "6-8 years", "9-11 years"],
  };
  // Sample data for location and company
  //   const [locations, setLocations] = useState([
  //     "Chennai",
  //     "Bangalore",
  //     "Hyderabad",
  //   ]);
  const [companies, setCompanies] = useState([
    "Company A",
    "Company B",
    "Company C",
  ]);
  const [selectedLocation, setSelectedLocation] = useState("");
  const [selectedCompany, setSelectedCompany] = useState("");

  // Sample data for cards
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://localhost:3000/job");
        if (!response.ok) {
          throw new Error("Failed to fetch data");
        }
        const data = await response.json();
        setData(data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching data:", error);
        const data = error;
        setData(data);
        // setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Filter function
  const filterData = () => {
    // You can filter data based on selectedLocation and selectedCompany
    // For simplicity, I'm just returning the original data here
    return data;
  };

  return (
    <div style={{ minHeight: "100vh", color: "white" }}>
      <div className="container">
        <div className="row mt-2">
          {/* Left side with filters */}
          <div className="col-md-4">
            <p>Filters</p>
            <hr />
            <Dropdown data={company} />
            <Dropdown data={location} />
            <Dropdown data={datePosted} />
            <Dropdown data={salary} />
            <Dropdown data={skills} />
            <Dropdown data={exp} />
            <Dropdown data={education} />
          </div>

          {/* Right side with cards */}
          <div className="col-md-8">
            <h2>{data.length} Jobs Available</h2>
            <div className="row">
              {loading ? (
                <p>{data.message}</p>
              ) : (
                data.map((item) => (
                  <Card
                    key={item.id}
                    data={item}
                    style={{ marginBottom: 16 }}
                  />
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default YourComponent;
