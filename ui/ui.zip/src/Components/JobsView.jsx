import React, { useState } from "react";
import Card from "./Card"; // Assuming you have a Card componentimport * as React from 'react';
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import AccordionExpandDefault from "./Accordian/Accordian";

const JobsView = () => {
  // Sample data for location and company
  const location = {
    name: "Location",
    value: ["Chennai", "Mumbai", "Coimbatore"],
  };
  const [companies, setCompanies] = useState([
    "Company A",
    "Company B",
    "Company C",
  ]);
  const [selectedLocation, setSelectedLocation] = useState("");
  const [selectedCompany, setSelectedCompany] = useState("");

  // Sample data for cards
  const [data, setData] = useState([
    {
      id: 1,
      image:
        "https://substackcdn.com/image/fetch/f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8ed3d547-94ff-48e1-9f20-8c14a7030a02_2000x2000.jpeg",
      name: "Item 1",
      location: "Chennai",
      company: "Company A",
    },
    { id: 2, name: "Item 2", location: "Bangalore", company: "Company B" },
    { id: 3, name: "Item 3", location: "Hyderabad", company: "Company C" },
  ]);

  // Filter function
  const filterData = () => {
    // You can filter data based on selectedLocation and selectedCompany
    // For simplicity, I'm just returning the original data here
    return data;
  };

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "100vh",
      }}
    >
      <div
        className="container"
        style={{ width: "70%", display: "flex", color: "white" }}
      >
        <div className="row">
          {/* Left side with filters */}
          <div className="col-md-4">
            <h2>Filters</h2>
            <AccordionExpandDefault data={location} />
          </div>

          {/* Right side with cards */}
          <div className="col-md-8">
            <h2>Data</h2>
            <div
              className="row"
              style={{ display: "flex", flexDirection: "column" }}
            >
              {filterData().map((item) => (
                <Card key={item.id} data={item} style={{ marginBottom: 16 }} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobsView;
